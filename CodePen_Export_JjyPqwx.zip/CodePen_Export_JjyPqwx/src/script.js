$(".random").click(function(){
    var parent = $("#maingrid");
    var divs = parent.children();
    while (divs.length) {
        parent.append(divs.splice(Math.floor(Math.random() * divs.length), 1)[0]);
    }
});
$(".random").click(function(){
    var parent = $("#maingrid2");
    var divs = parent.children();
    while (divs.length) {
        parent.append(divs.splice(Math.floor(Math.random() * divs.length), 1)[0]);
    }
});
//set up individual html pages when you have an offline environment to see if this script still works

//setup script to add new divs so the user can add their own cards (right now the function attached is the same as the randomize button)
/*$(".addnew").click(function(){
    var parent = $("#maingrid");
    var divs = parent.children();
    while (divs.length) {
        parent.append(divs.splice(Math.floor(Math.random() * divs.length), 1)[0]);
    }
});
*/
$('#spanish').val();
$('#english').val();

    // Insert elements on click of the button
    


//actually got it to prepend something, not what I want tho
//need to create the div and then define its elements
var $newDiv = $("<flipcard/>")   // creates a div element
                 .attr("id", "someID")  // adds the id
                 .addClass("cards")   // add a class
                 .html("<div>stuff here</div>");
$(".addnew").click(function(){
         var spanishinput = $('#spanish').val();
         var englishinput = $('#english').val();
        // Creating a div element at the start
        $(".cards").prepend(spanishinput); 
    });    